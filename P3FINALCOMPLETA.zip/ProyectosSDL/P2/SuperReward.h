#pragma once
#include "checkML.h"
#include "Reward.h"

class SuperReward : public Reward {
public:
	SuperReward() {};
	SuperReward(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		Reward(pos, w, h, speed, 5, app, playState, t) {};

	~SuperReward() {};

	void act();
};