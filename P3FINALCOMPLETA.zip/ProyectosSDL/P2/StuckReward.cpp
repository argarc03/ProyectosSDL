#include "StuckReward.h"
#include "LengthenReward.h"
#include "Application.h"
#include "PlayState.h"

void StuckReward::act() {
	playState->setStickyBall(true);
}