#pragma once

#include "GameState.h"

class PlayState;

class PauseState : public GameState {
private:
	static PlayState* playState;
public:
	PauseState(Application* app, PlayState* playState);

	virtual void handleEvent(SDL_Event& e);

	static void resume(Application* app);
	static void save(Application* app);
	static void mainMenu(Application* app);
};