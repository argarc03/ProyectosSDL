#pragma once
#include "ScreenState.h"
class GameOverState :public ScreenState {
public:
	GameOverState(Application* app, uint32_t time, string textureName) : ScreenState(app, time, textureName, playState) {};

	virtual void update() {
		if (SDL_GetTicks() - startTime > timeInScreen) {
			app->getStateMachine()->popState(1);
		}
	}
};