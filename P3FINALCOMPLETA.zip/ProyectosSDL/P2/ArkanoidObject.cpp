#include "ArkanoidObject.h"
#include <iostream>
#include <fstream>

void ArkanoidObject::loadFromFile(ifstream& in) {
	in >> pos;
}

void ArkanoidObject::saveToFile(ofstream& out) {
	out << pos << endl;
}