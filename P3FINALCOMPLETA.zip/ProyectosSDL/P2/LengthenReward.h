#pragma once
#include "checkML.h"
#include "Reward.h"

class LengthenReward : public Reward {
public:
	LengthenReward() {};
	LengthenReward(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		Reward(pos, w, h, speed, 2, app, playState, t) {};

	~LengthenReward() {};

	void act();
};
