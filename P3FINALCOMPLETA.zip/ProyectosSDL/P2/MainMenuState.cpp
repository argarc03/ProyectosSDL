#include "MainMenuState.h"

MainMenuState::MainMenuState(Application* app): GameState(app) {
	init();
}

void MainMenuState::newGame(Application* app) {
	app->getStateMachine()->pushState(new PlayState(app));
	app->getStateMachine()->currentState()->awake();
}

void MainMenuState::continueGame(Application* app) {
	app->getStateMachine()->pushState(new PlayState(app, app->inputTextLoad()));//cuando tengamos TTF lo quitaremos de app
}

void MainMenuState::quit(Application* app) {
	app->setExit(true);
}

void MainMenuState::init() {
	stage.push_back(new Text(600, 200, Vector2D(100, 50), TextureLoader::getInstance()->get("TitleText")));

	int width, height;
	width = 100;
	height = 100;


	//New Game Button
	stage.push_back(new Button(250, 50, Vector2D(app->WIN_WIDTH / 2 - 125, app->WIN_HEIGHT / 2), app, MainMenuState::newGame, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(NewGameText)]));
	//Continue Game Button
	stage.push_back(new Button(300, 50, Vector2D(app->WIN_WIDTH / 2 - 150, app->WIN_HEIGHT / 2 + 100), app, MainMenuState::continueGame, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(ContinueGameText)]));
	//Quit Button
	stage.push_back(new Button(100, 50, Vector2D(app->WIN_WIDTH / 2 - 50, app->WIN_HEIGHT / 2 + 200), app, MainMenuState::quit, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(QuitText)]));
}