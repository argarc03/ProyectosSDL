#pragma once

#include "GameState.h"

class EndState :public GameState {
public:
	EndState(Application* app);

	static void mainMenu(Application* app);
	static void quit(Application* app);
};