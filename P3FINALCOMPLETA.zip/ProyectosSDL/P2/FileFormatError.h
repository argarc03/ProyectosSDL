#pragma once

#include "checkML.h"
#include "ArkanoidError.h"
#include <string>

class FileFormatError : public ArkanoidError {
private:
	string type = "";
	string info = "";
public:
	FileFormatError(string type) : ArkanoidError("Error: the format used is not correct"), type(type) {};
	FileFormatError(string type, string info) : ArkanoidError("Error: the format used is not correct"), type(type), info(info) {};
	~FileFormatError() {};

	string getType() { return type; };
	string getAditionalInfo() { return info; };
};

