#include "Vector2D.h"
#include <math.h>

using namespace std;

double Vector2D::getX() const {
	return x;
}

double Vector2D::getY() const {
	return y;
}

//normalize the vector
void Vector2D::normalize() {
	double module = sqrt(pow(x, 2) + pow(y, 2));
	x = x / module;
	y = y / module;
}

//sum between vectors
Vector2D Vector2D::operator+(const Vector2D& u) {
	return Vector2D(x + u.x, y + u.y);
}

//difference between vectors
Vector2D Vector2D::operator-(const Vector2D& u) {
	return Vector2D(x - u.x, y - u.y);
}

//multiplies with another vector
double Vector2D::operator*(const Vector2D& u) {
	return x * u.x + y * u.y;
}

//multiplies with number
Vector2D Vector2D::operator*(double num) {
	return Vector2D(x * num, y *num);
}

//reads "x y"
istream& operator>>(istream& in, Vector2D& v) {
	in >> v.x >> v.y;
	return in;
}

//writes "x y"
ostream& operator<<(ostream& out, const Vector2D& v) {
	out << v.x << " " << v.y;
	return out;
}
