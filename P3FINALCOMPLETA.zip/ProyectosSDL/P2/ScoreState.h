#pragma once
#include "GameState.h"
#include <map>

using namespace std;

class ScoreState :public GameState {
private:
	map<pair<int, string>, string> scores;  //Score, date:  Nick
	Texture** nicks = nullptr;
	Texture** dates = nullptr;
public:
	ScoreState(Application* app, int score);
	virtual ~ScoreState() {
		for (int i = 0; i < HIGH_SCORE_TOP_SIZE; i++) {
			delete nicks[i];
			delete dates[i];
		}

		delete[] nicks;
		delete[] dates;
	};
	virtual void update() {};
	void loadScore();
	void saveScore(int time);
	string inputNickSave();
	static void endState(Application* app);
	int getPlayerScorePosition(string nick);
};

