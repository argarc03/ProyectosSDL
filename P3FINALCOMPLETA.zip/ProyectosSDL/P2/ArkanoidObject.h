#pragma once

#include "checkML.h"
#include "SDLGameObject.h"

typedef unsigned int uint;

class ArkanoidObject : public SDLGameObject {
protected:
public:
	ArkanoidObject() {};
	ArkanoidObject(uint w, uint h, Vector2D pos, Texture* t) :SDLGameObject( w,  h,  pos, t) {};
	virtual ~ArkanoidObject() {};

	// Loads from file the ArkanoidObject's position
	virtual void loadFromFile(ifstream& in);
	// Loads from file the ArkanoidObject's position
	virtual void saveToFile(ofstream& out);
};