#include "MultipleReward.h"
#include "Application.h"
#include "PlayState.h"

void MultipleReward::act(){
	playState->multiplyBall();
}