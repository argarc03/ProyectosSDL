#pragma once
#include "checkML.h"
#include <math.h>
#include "ArkanoidObject.h"

typedef unsigned int uint;

class Application;

class Counter : public ArkanoidObject {
private:
	uint totalDigits = 0;
	uint initialNumber = 0;
	uint number = 0;

	uint startTime = 0;
	uint delay = 0;
	bool stoped = false;

	int* digits;
public:
	Counter(Vector2D pos, uint w, uint h, uint initialNumber, uint totalDigits, Texture* t) : ArkanoidObject(w, h, pos, t), initialNumber(initialNumber), totalDigits(totalDigits) {
		digits = new int[totalDigits];
		stoped = true;
		delay = 0;
		startTime = SDL_GetTicks() - initialNumber;

		for (uint i = 0; i < totalDigits; i++)
			digits[i] = (initialNumber%int(pow(10, totalDigits - i))) / pow(10, totalDigits - 1 - i);
	};
	~Counter() {
		delete[] digits;
	};

	void render() const;
	void update();

	int getTime()const {
		if (stoped)
			return delay / 1000;
		else
			return (SDL_GetTicks() - startTime) / 1000;
	};
	void start() {
		if (stoped) {
			startTime = SDL_GetTicks() - delay;
			stoped = false;
		}
	}
	void stop() {
		if (!stoped) {
			stoped = true;
			delay = SDL_GetTicks() - startTime;
		}
	}
	void reset() {
		stoped = false;
		startTime = SDL_GetTicks();
		delay = 0;
	}

	//sets the counter's time
	void setTime(int time) {
		if (stoped) { //if it's stopped, it sets a delay
			delay = time / 1000;
		}
		else {
			startTime = SDL_GetTicks() - time * 1000;
		}
	}

	// Loads from file the Counter's number
	virtual void loadFromFile(ifstream& in);
	// Saves to file the Counter's number
	virtual void saveToFile(ofstream& out);
};