#pragma once
#include "checkML.h"
#include "MovingObject.h"
#include "ArkanoidObject.h"
#include <list>
class Laser :
	public MovingObject
{
private:
	list<GameObject*>::iterator it; //iterator that pointing to its object's position
public:
	Laser() {};
	Laser(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		MovingObject(pos, w, h, speed, app, playState, t) {};
	virtual ~Laser() {};

	virtual void update();
	void setItList(list<GameObject*>::iterator it);
};