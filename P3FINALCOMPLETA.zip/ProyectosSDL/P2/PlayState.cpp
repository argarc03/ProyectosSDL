#include "PlayState.h"
#include <iostream>
#include <fstream>
#include "ScreenState.h"
#include "ScoreState.h"
#include "Paddle.h"
#include "Ball.h"
#include "LevelReward.h"
#include "LifeReward.h"
#include "LengthenReward.h"
#include "Laser.h"
#include "LaserReward.h"
#include "ShortenReward.h"
#include "StuckReward.h"
#include "SuperReward.h"
#include "MultipleReward.h"
#include "Enemy.h"
#include "GameOverState.h"
#include "PauseState.h"
#include "EndState.h"

//NUEVA PARTIDA
PlayState::PlayState(Application* app) : GameState(app) {
	lives = app->TOTAL_LIVES;

	init();

	blocksMap->load(app->LEVELS_PATH + "level" + to_string(level) + ".ark", TextureLoader::getInstance()->get("BricksText"));
}

//CARGAR PARTIDA
PlayState::PlayState(Application* app, string code) : GameState(app) {
	init();
	load(code);
	//resets timecounter
	timeCounter->reset();
	timeCounter->setTime(startTime);
}

//Saves the game to filename.txt.
void PlayState::save(string filename) {
	filename = app->inputTextSave();

	ofstream out;
	out.open(filename);

	blocksMap->save(out);						//blocksmap
	out << level << endl;						//level
	timeCounter->saveToFile(out);				//time
	out << lives << endl;						//lifes
	paddle->saveToFile(out);					//paddle
	ball->saveToFile(out);						//ball
	//additional balls
	out << numBalls << endl;
	if (ball2 != nullptr)
		ball2->saveToFile(out);
	if (ball3 != nullptr)
		ball3->saveToFile(out);

	out << numEnemies << endl;							//n� de enemies guardados
	for (auto it = firstEnemy; it != firstReward; ++it) {	//rewards
		(*it)->saveToFile(out);
	}
	out << numRewards << endl;							//n� de rewards guardados
	for (auto it = firstReward; it != stage.end(); ++it) {	//rewards
		(*it)->saveToFile(out);
	}

	out.close();

	//saves the game's configuration
	app->saveConfig();
}

void PlayState::handleEvent(SDL_Event& event) {
	GameState::handleEvent(event);
	if (event.type == SDL_KEYDOWN) {
		if (event.key.keysym.sym == SDLK_ESCAPE) {
			//paused = true;
			timeCounter->stop();

			app->getStateMachine()->pushState(new PauseState(app, this));
		}
	}
}

void PlayState::update() {
	GameState::update();

	//Generate an Enemy
	if (numEnemies < app->MAX_ENEMIES) {
		int random = rand() % app->ENEMY_PROBABILITY + 1;
		if (random == 1)
			spawnEnemy();
	}

	if (ball->getY() >= app->WIN_HEIGHT + 2 * app->BALL_SIZE)//If the ball is under the paddle, it is lost
		ballLost(ball);

	if (levelWin) {//checks if level is completed

		levelCompleted();
	}
	else if (gameOver) {//gameOver
		app->getStateMachine()->pushState(new EndState(app));
		app->getStateMachine()->pushState(new GameOverState(app, 3000, "GameOverText"));
	}
}

void PlayState::init() {
	//BlocksMap
	blocksMap = new BlocksMap(Vector2D(app->WIN_WIDTH / 2 - (app->WIN_WIDTH - 2 * app->WALL_WIDTH - 2 * app->GAP_WIDTH) / 2, 6 * app->WALL_WIDTH + app->GAP_WIDTH), app->WIN_WIDTH - 2 * app->WALL_WIDTH - 2 * app->GAP_WIDTH, app->WIN_HEIGHT / 2, app);
	stage.push_back(blocksMap);

	//Walls
	for (uint i = 0; i < NUM_WALLS; i++) {
		walls[i] = new Wall(app->wallAtrib[i].w, app->wallAtrib[i].h, app->wallAtrib[i].pos, app->wallAtrib[i].coll, TextureLoader::getInstance()->get(app->wallAtrib[i].textureName));
		stage.push_back(walls[i]);
	}

	//TimeText
	stage.push_back(new Text(4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, Vector2D(0, 0), TextureLoader::getInstance()->get("TimeText")));
	//LevelText
	stage.push_back(new Text(4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, Vector2D(app->WIN_WIDTH / 2 + 12 * app->WALL_WIDTH, 0), TextureLoader::getInstance()->get("LevelText")));
	//TimeCounter
	timeCounter = new Counter(Vector2D(3 * app->WALL_WIDTH + 2 * app->WALL_WIDTH, 0), 4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, 0, app->NUM_DIGITS_SCORE, TextureLoader::getInstance()->get("DigitsText"));
	stage.push_back(timeCounter);
	//paddle
	paddle = new Paddle(Vector2D(app->WIN_WIDTH / 2 - app->PADDLE_WIDTH / 2, app->WIN_HEIGHT - 2 * app->WALL_WIDTH), app->PADDLE_WIDTH, app->PADDLE_HEIGHT, Vector2D(0, 0), app, this, TextureLoader::getInstance()->get("PaddleText"));
	stage.push_back(paddle);
	//ball
	ball = new Ball(Vector2D(app->WIN_WIDTH / 2 - app->BALL_SIZE / 2, app->WIN_HEIGHT - 3 * app->WALL_WIDTH), app->BALL_SIZE, app->BALL_SIZE, Vector2D(0, -(app->BALL_SPEED)), app, this, paddle, TextureLoader::getInstance()->get("BallText"));
	stage.push_back(ball);
	//ball2
	ball2 = nullptr;//new Ball(Vector2D(app->WIN_WIDTH / 2 - app->BALL_SIZE / 2, app->WIN_HEIGHT - 3 * app->WALL_WIDTH), app->BALL_SIZE, app->BALL_SIZE, Vector2D(0, -(app->BALL_SPEED)), app, this, paddle, app->textures[TextureName(BallText)]);
	//ball3
	ball3 = nullptr;//new Ball(Vector2D(app->WIN_WIDTH / 2 - app->BALL_SIZE / 2, app->WIN_HEIGHT - 3 * app->WALL_WIDTH), app->BALL_SIZE, app->BALL_SIZE, Vector2D(0, -(app->BALL_SPEED)), app, this, paddle, app->textures[TextureName(BallText)]);

	//Lives Counter
	stage.push_back(new LifeCounter(Vector2D(app->WALL_WIDTH + 2 * app->GAP_WIDTH, app->WIN_HEIGHT - app->WALL_WIDTH + app->GAP_WIDTH), app->PADDLE_WIDTH, app->WALL_WIDTH - 2 * app->GAP_WIDTH, app->TOTAL_LIVES, lives, TextureLoader::getInstance()->get("PaddleText")));
	//Level Counter
	stage.push_back(new LevelCounter(Vector2D(app->WIN_WIDTH - 2 * app->WALL_WIDTH, 0), 2 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, level, app->NUM_DIGITS_LEVEL, TextureLoader::getInstance()->get("DigitsText")));
	lastLevelObject = --(stage.end());
}

//Loads the game from filename.txt
void PlayState::load(string filename) {
	blocksMap->load(filename, TextureLoader::getInstance()->get("BricksText")); //blocksmap
	ifstream in;
	in.open(filename);
	string s;
	for (uint i = 0; i < blocksMap->getnRows() + 1; i++) getline(in, s); //ignore the blocksmap lines in the file
	in >> level;														//level
	if (level < 0 || level > app->TOTAL_LEVELS)
		throw FileFormatError("Invalid level", "Invalid level: " + to_string(level));
	in >> startTime;													//time
	in >> lives;														//lives
	if (lives < 0 || lives > app->TOTAL_LIVES)
		throw FileFormatError("Invalid lives", "Invalid lives: " + to_string(lives));


	paddle->loadFromFile(in);

	ball->loadFromFile(in);
	in >> numBalls;
	if (numBalls > 1) {
		stage.push_back(ball2);
		ball2->loadFromFile(in);
		if (numBalls == 3)
		{
			stage.push_back(ball3);
			ball3->loadFromFile(in);
		}
	}

	//Create some stuff before loading the rewards
	in >> numEnemies;													//numEnemies
	auto it = stage.end();
	for (int i = 0; i < numEnemies; i++) {								//enemies
		Enemy* e = new Enemy(Vector2D(0, 3 * app->WALL_WIDTH + app->GAP_WIDTH), app->ENEMY_WIDTH, app->ENEMY_HEIGHT, app, this, TextureLoader::getInstance()->get("EnemyText"));
		e->loadFromFile(in);
		stage.push_back(e);
		auto it = --(stage.end());
		e->setItList(it);
		if (firstEnemy == stage.end())
			firstEnemy = it; //actualiza firstEnemy
	}
	lastEnemy = --it; //actualiza lastEnemy

	in >> numRewards;													//numRewards
	if (numRewards < 0)
		throw FileFormatError("Invalid number of rewards", "Invalid number of rewards: " + to_string(numRewards));
	for (int i = 0; i < numRewards; i++)								//rewards
	{
		int rewardType;
		in >> rewardType;												//new reward type

		Reward* r = nullptr;

		switch (rewardType) {
		case LevelRew:
			r = new LevelReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case LifeRew:
			r = new LifeReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case LengthenRew:
			r = new LengthenReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case ShortenRew:
			r = new ShortenReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case StuckRew:
			r = new StuckReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case SuperRew:
			r = new SuperReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case MultipleRew:
			r = new MultipleReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		case LaserRew:
			r = new LaserReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		default:
			r = new LevelReward(Vector2D(0, 0), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
			break;
		}

		r->loadFromFile(in);

		stage.push_back(r);
		auto itFR = --(stage.end());
		if (firstReward == stage.end())
			firstReward = itFR;
		r->setItList(itFR);
	}
	in.close();
}

//destroy all rewards
void PlayState::destroyRewards() {
	for (auto it = firstReward; it != stage.end();) {
		delete *it;
		it = stage.erase(it);
	}
	firstReward = stage.end();

	numRewards = 0;
}

//destroys all enemies
void PlayState::destroyEnemies() {
	if (numEnemies > 0) {
		for (auto it = firstEnemy; it != firstReward;) {
			delete *it;
			it = stage.erase(it);
		}
		firstEnemy = stage.end();
		lastEnemy = stage.end();

		numRewards = 0;
	}
}

//Destroys the objects that changes between levels.
void PlayState::destroyObjects() {
	destroyEnemies(); //Destroy the enemies
	destroyRewards(); //Destroys the rewards

	startTime = timeCounter->getTime();

	for (int i = 0; i < app->NUM_TEMPORAL_OBJECTS + numLasers + numBalls - 1; i++) {
		auto prev = lastLevelObject;
		--prev;
		delete *lastLevelObject;
		stage.erase(lastLevelObject);
		lastLevelObject = prev;
	}
	lastLevelObject = stage.end();
}

//Creates the objects that changes between levels.
void PlayState::createObjects() {
	//paddle
	paddle = new Paddle(Vector2D(app->WIN_WIDTH / 2 - app->PADDLE_WIDTH / 2, app->WIN_HEIGHT - 2 * app->WALL_WIDTH), app->PADDLE_WIDTH, app->PADDLE_HEIGHT, Vector2D(0, 0), app, this, TextureLoader::getInstance()->get("PaddleText"));
	stage.push_back(paddle);
	//ball
	ball = new Ball(Vector2D(app->WIN_WIDTH / 2 - app->BALL_SIZE / 2, app->WIN_HEIGHT - 3 * app->WALL_WIDTH), app->BALL_SIZE, app->BALL_SIZE, Vector2D(0, -(app->BALL_SPEED)), app, this, paddle, TextureLoader::getInstance()->get("BallText"));
	stage.push_back(ball);
	//time counter
	timeCounter = new Counter(Vector2D(3 * app->WALL_WIDTH + 2 * app->WALL_WIDTH, 0), 4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, startTime, app->NUM_DIGITS_SCORE, TextureLoader::getInstance()->get("DigitsText"));
	stage.push_back(timeCounter);
	timeCounter->reset();
	timeCounter->setTime(startTime);
	//life counter
	lifeCounter = new LifeCounter(Vector2D(app->WALL_WIDTH + 2 * app->GAP_WIDTH, app->WIN_HEIGHT - app->WALL_WIDTH + app->GAP_WIDTH), app->PADDLE_WIDTH, app->WALL_WIDTH - 2 * app->GAP_WIDTH, app->TOTAL_LIVES, lives, TextureLoader::getInstance()->get("PaddleText"));
	stage.push_back(lifeCounter);
	//level counter
	stage.push_back(new LevelCounter(Vector2D(app->WIN_WIDTH - 2 * app->WALL_WIDTH, 0), 2 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, level, app->NUM_DIGITS_LEVEL, TextureLoader::getInstance()->get("DigitsText")));
	lastLevelObject = --(stage.end());
}

//Resets the objects in scene (paddle, ball, etc.) and update (delete and create) the counters (lifes, level, etc.).
void PlayState::reset() {
	destroyObjects();
	createObjects();

	numBalls = 1;
	numEnemies = 0;
	numLasers = 0;
	levelWin = false;
}

//Decreases lifes and asks if the player is still alive.
void PlayState::ballLost(Ball* b) {
	if (numBalls <= 1) {
		lives--;

		reset();
		if (lives == 0)
			gameOver = true;
	}
	else
	{
		//erase the lost ball
		if (b == ball) { //The lost ball is the main ball
			if (numBalls == 2) {
				if (ball2 == nullptr)
					ball = ball3;
				else
					ball = ball2;
			}
			else
				ball = ball2;
		}

		stage.remove(b);

		numBalls--;
	}
}

//Receives an iterator pointing to an object inside objects, destroy that object and erase it from the list
void PlayState::killObject(list<GameObject*>::iterator it) {
	delete *it;
	stage.erase(it);
}

void PlayState::killReward(list<GameObject*>::iterator it) {
	if (it == firstReward)
		++firstReward; //Advance firstReward in case the firstReward is being deleted

	killObject(it);

	numRewards--;
}

void PlayState::killLasers(list<GameObject*>::iterator it) {
	killObject(it);

	numLasers--;
}

//increase the lives in 1
void PlayState::lifeUp() {
	if (lives < app->TOTAL_LIVES) {
		lives++;
		lifeCounter->addLife();
	}
}

//enlarge/shorten the paddle width depending on the value
void PlayState::modifyPaddle(int value) {
	setStuckBall(false);
	paddle->modifyWidth(value);
}

void PlayState::setStickyBall(bool b) {
	ball->setSticky(b);
}

void PlayState::setStuckBall(bool b) {
	if (ball->getStuck()) {
		ball->setStuck(b);
		if (!b)
		{
			ball->setSpeedUp();
			ball->setSticky(b);
		}
	}
}

bool PlayState::getStickyBall() {
	return ball->getSticky();
}

void PlayState::setSuperBall(bool b) {
	ball->setSuper(b);
}

//Creates 2 additional balls in different directions at the ball position and inserts them before rewards in the objects list
void PlayState::multiplyBall() {
	if (numBalls == 1) {
		numBalls = numBalls + 2;


		ball2 = new Ball(Vector2D(ball->getX(), ball->getY()), app->BALL_SIZE, app->BALL_SIZE, Vector2D(ball->getSpeed().getX() - 1, ball->getSpeed().getY() + 1), app, this, paddle, TextureLoader::getInstance()->get("BallText"));
		stage.insert(lastLevelObject, ball2);
		auto it = lastLevelObject;
		--it;
		ball2->setStuck(false);


		ball3 = new Ball(Vector2D(ball->getX(), ball->getY()), app->BALL_SIZE, app->BALL_SIZE, Vector2D(ball->getSpeed().getX() + 1, ball->getSpeed().getY() + 1), app, this, paddle, TextureLoader::getInstance()->get("BallText"));
		stage.insert(lastLevelObject, ball3);
		it = lastLevelObject;
		--it;
		ball3->setStuck(false);
	}
}

//Sets paddle->laser = true and deactivates other rewards
void PlayState::setPaddleLasers(bool value) {
	setStuckBall(false);
	paddle->setLasers(value);
}

//Creates 2 lasers at paddle's position going upwards 
void PlayState::createLasers() {

	Laser* leftLaser = new Laser({ double(paddle->getX() + (paddle->getW() / 4)),double(paddle->getY()) }, app->LASER_WIDTH, app->LASER_HEIGHT, { 0, -(app->LASER_SPEED) }, app, this, TextureLoader::getInstance()->get("LaserText"));
	stage.insert(lastLevelObject, leftLaser);
	auto it = lastLevelObject;
	--it;
	leftLaser->setItList(it);


	Laser* rightLaser = new Laser({ double(paddle->getX() + (paddle->getW() - (paddle->getW() / 4))),double(paddle->getY()) }, app->LASER_WIDTH, app->LASER_HEIGHT, { 0, -(app->LASER_SPEED) }, app, this, TextureLoader::getInstance()->get("LaserText"));
	stage.insert(lastLevelObject, rightLaser);
	it = lastLevelObject;
	--it;
	rightLaser->setItList(it);

	numLasers += 2;
}

//Spawn an enemy at a random X position at the top of the map, and inserts it in objects list
//before the first reward
void PlayState::spawnEnemy() {
	numEnemies++;
	double rndX = rand() % (blocksMap->getX() + blocksMap->getW() - app->ENEMY_WIDTH - app->GAP_WIDTH) + blocksMap->getX();

	auto creationIt = stage.end();

	if (numEnemies == 1) //no enemies created
		creationIt = firstReward; //the enemy will be inserted before the first reward
	else if (numEnemies > 1)
		creationIt = ++lastEnemy;

	Enemy* enemy = new Enemy(Vector2D(rndX, 3 * app->WALL_WIDTH + app->GAP_WIDTH), app->ENEMY_WIDTH, app->ENEMY_HEIGHT, app, this, TextureLoader::getInstance()->get("EnemyText"));
	stage.insert(creationIt, enemy);

	if (numEnemies == 1) { //this enemy is the first one
		firstEnemy = --creationIt;
		lastEnemy = creationIt;
	}
	else
		lastEnemy = --creationIt;


	enemy->setItList(creationIt);
}

//detects collision with paddle (used by rewards, for example)
bool PlayState::collidesPaddle(const SDL_Rect& rect) {
	Vector2D p2 = { double(rect.x),  double(rect.y) + double(rect.h) }; // bottom-left
	Vector2D p3 = { double(rect.x) + double(rect.w),  double(rect.y) + double(rect.h) }; // bottom-right

	if (paddle->getY() <= p2.getY() && paddle->getY() + paddle->getH() > p2.getY() && paddle->getX() <= p3.getX() && paddle->getX() + paddle->getW() >= p2.getX())
		return true;
	return false;
}

void PlayState::destroyExtraBall(Ball* b) {
	delete b;

	stage.remove(b);
	b = nullptr;
}

//create a random reward at the rect position
void PlayState::createReward(const SDL_Rect& rect) {
	Reward* r = nullptr;
	int random = rand() % app->NUM_REWARDS + 1; //generate random
	switch (random) {
	case LevelRew:
		r = new LevelReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case LifeRew:
		r = new LifeReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case LengthenRew:
		r = new LengthenReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case ShortenRew:
		r = new ShortenReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case StuckRew:
		r = new StuckReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case SuperRew:
		r = new SuperReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case MultipleRew:
		r = new MultipleReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	case LaserRew:
		r = new LaserReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	default:
		r = new LevelReward(Vector2D(rect.x, rect.y), app->REWARD_WIDTH, app->REWARD_HEIGHT, Vector2D(0, app->REWARD_SPEED), app, this, TextureLoader::getInstance()->get("RewardsText"));
		break;
	}

	stage.push_back(r);
	auto itFR = --(stage.end());
	if (firstReward == stage.end())
		firstReward = itFR;
	r->setItList(itFR);

	numRewards++;
}

void PlayState::levelCompleted() {
	if (level < app->TOTAL_LEVELS) { //If it's not the last level, the Level Completed screen is shown and the map loads the next level.
		level++;

		//destroy and create the blocksmap
		delete *stage.begin();
		stage.erase(stage.begin());

		blocksMap = new BlocksMap(Vector2D(app->WIN_WIDTH / 2 - (app->WIN_WIDTH - 2 * app->WALL_WIDTH - 2 * app->GAP_WIDTH) / 2, 6 * app->WALL_WIDTH + app->GAP_WIDTH), app->WIN_WIDTH - 2 * app->WALL_WIDTH - 2 * app->GAP_WIDTH, app->WIN_HEIGHT / 2, app);
		stage.push_front(blocksMap);
		blocksMap->load(app->LEVELS_PATH + "level" + to_string(level) + ".ark", TextureLoader::getInstance()->get("BricksText"));
		reset();

		timeCounter->stop();
		app->getStateMachine()->pushState(new ScreenState(app, 3000, "LevelCompletedText", this));

	}
	else { //If the level completed is the last level, the You Win screen is shown.
		app->getStateMachine()->pushState(new EndState(app));
		app->getStateMachine()->pushState(new ScoreState(app, timeCounter->getTime()));
		app->getStateMachine()->pushState(new ScreenState(app, 3000, "WinText", this));
	}
}

bool PlayState::blocksMapCollision(const SDL_Rect& rect, const Vector2D& vel, Vector2D& collVector, bool destroy) {
	if (rect.y < blocksMap->getY() + blocksMap->getH() + app->GAP_WIDTH) { //Checks that the ball is inside the limits of blocksMap
		Block* block = blocksMap->collides(rect, vel, collVector); //Gets the block the ball is colliding with 
		if (block != nullptr) {
			if (destroy) {
				blocksMap->ballHitsBlock(block);//Destroy the block

												//Create random reward (PROBABILITY = 1/5)
				int random = rand() % app->REWARD_PROBABILITY + 1;
				if (random == 1)
					createReward(rect);

				if (ball->getSuper())
					collVector = { 0,0 };

				if (blocksMap->getNumBlocks() == 0)//Checks if the level is over
					levelWin = true;
			}
			return true;
		}
	}

	return false;
}

//Returns true if the ball collides with an object and if there is, modifies the collVector.
bool PlayState::collides(const SDL_Rect& rect, const Vector2D& vel, Vector2D& collVector) {
	//BlocksMap
	if (blocksMapCollision(rect, vel, collVector, true))
		return true;
	//Walls
	if (wallCollision(rect, vel, collVector))
		return true;
	//Paddle
	if (rect.y > blocksMap->getY() + blocksMap->getH() + app->GAP_WIDTH) { //Checks if the ball is under blocksMap
		if (paddle->collides(rect, collVector)) {
			if (ball->getSticky()) {
				ball->setStuck(true);
				setStickyBall(false);
			}
			return true;
		}
	}
	//Enemy
	if (numEnemies > 0) {
		for (auto it = firstEnemy; it != firstReward; ++it) {
			Enemy* enemy = dynamic_cast<Enemy*>(*(it));

			if (enemy->collides(rect, collVector)) {
				if (it == firstEnemy)
					++firstEnemy; //Advance firstReward in case the firstReward is being deleted
				else if (it == lastEnemy)
					--lastEnemy;
				enemy->destroy();

				numEnemies--;
				return true;
			}
		}
	}

	return false;
}

bool PlayState::wallCollision(const SDL_Rect& rect, const Vector2D& vel, Vector2D& collVector) {
	if (rect.x < 2 * app->WALL_WIDTH) { //Left wall
		if (walls[WallName(LeftWall)]->collides(rect, vel, collVector))
			return true;
	}
	else if (rect.x + rect.w > app->WIN_WIDTH - 2 * app->WALL_WIDTH) { //Right wall
		if (walls[WallName(RightWall)]->collides(rect, vel, collVector))
			return true;
	}
	if (rect.y < 4 * app->WALL_WIDTH) { //Top wall
		if (walls[WallName(TopWall)]->collides(rect, vel, collVector))
			return true;
	}

	return false;
}
