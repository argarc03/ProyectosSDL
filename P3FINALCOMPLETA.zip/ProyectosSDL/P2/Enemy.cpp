#include "Enemy.h"
#include "Application.h"
#include "PlayState.h"

void Enemy::render() const {
	SDL_Rect destRect = getRect();

	texture->renderFrame(destRect, 0, frame);
}

void Enemy::update() {
	Vector2D collVector = { 0,0 };
	//Move
	if (getY() > app->WIN_HEIGHT - 100)//ensures the enemy is not going under the paddle
		speed = { 0, app->ENEMY_SPEED*(-1) };
	else if (!(playState->wallCollision(getRect(), speed, collVector)) && !(playState->blocksMapCollision(getRect(), speed, collVector, false))) {//ensures the enemy will not go through a wall or block
		if (rand() % probability + 1 == 1) {
			speed = Vector2D(((double(rand()) / double(RAND_MAX)) * (app->ENEMY_SPEED - (-(app->ENEMY_SPEED)))) + (-(app->ENEMY_SPEED)),
				((double(rand()) / double(RAND_MAX)) * (app->ENEMY_SPEED - (-(app->ENEMY_SPEED)))) + (-(app->ENEMY_SPEED)));//generate random direction
		}
	}
	else//if there is a collision, it applies the collision vector to the speed
		speed = collVector;


	MovingObject::update();
	//Animation
	currentTime++;
	if (currentTime >= frameRate) {
		frame = (frame + 1) % texture->getNumCols();
		currentTime = 0;
	}
}

bool Enemy::collides(const SDL_Rect& ballRect, Vector2D& collVector) {
	if (SDL_HasIntersection(&(getRect()), &ballRect)) { //Checks if there is a collision with ball
														//collVector will be a random collision vector
		int randomX = rand() % probability;
		int randomY = rand() % probability;
		collVector = { double(randomX), double(randomY) };
		collVector.normalize();
		return true;
	}

	return false;
}

void Enemy::setItList(list<GameObject*>::iterator _it) {
	it = _it;
}

void Enemy::destroy() {
	playState->killObject(it);
}