#include "GameStateMachine.h"
#include "GameState.h"

GameStateMachine::~GameStateMachine() {
	while (!stateStack.empty()) {
		delete stateStack.top();
		stateStack.pop();
	}
}

//pushes a new state into the GSM
void GameStateMachine::pushState(GameState* s) {
	stateStack.push(s);
}

//pops n states (default: n = 1) starting from the top of the GSM
void GameStateMachine::popState(int n) {
	for (int i = 0; i < n && !stateStack.empty(); i++) {
		delete stateStack.top();
		stateStack.pop();

	}
}

//returns the top of the GSM
GameState* GameStateMachine::currentState() {
	return stateStack.top();
}
