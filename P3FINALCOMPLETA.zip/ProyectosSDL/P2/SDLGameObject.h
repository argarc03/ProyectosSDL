#pragma once
#include "GameObject.h"
#include "Vector2D.h"

class SDLGameObject :public GameObject{
protected:
	uint w = 0; uint h = 0;
	Vector2D pos = Vector2D(0, 0);

	Texture* texture = nullptr;
public:
	SDLGameObject() {};
	SDLGameObject(uint w, uint h, Vector2D pos, Texture* t) :w(w), h(h), pos(pos), texture(t) {};
	virtual ~SDLGameObject() {};

	virtual void render() const;
	virtual void update() {};
	virtual bool handleEvent(SDL_Event& e) { return false; };

	SDL_Rect getRect() const;

	uint getX() const { return pos.getX(); };
	uint getY() const { return pos.getY(); };
	uint getW() const { return w; };
	void setW(uint _w) { w = _w; };
	uint getH() const { return h; };
};

