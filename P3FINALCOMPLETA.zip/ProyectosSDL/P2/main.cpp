#include "SDL.h"
#include "SDL_image.h"
#include "checkML.h"
#include <iostream>
#include "Application.h"
#include "FileNotFoundError.h"
#include "SDLError.h"

using namespace std;

using uint = unsigned int;

int main(int argc, char* argv[]) {
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	try {
		Application* app = new Application();
		app->run();
		delete app;
	}
	catch (SDLError& e) {
		cout << e.what() << endl;
		system("pause");
	}
	catch (FileNotFoundError& e) {
		cout << e.what() << endl;
		system("pause");
	}
	catch (FileFormatError& e) {
		cout << e.what() << endl << e.getType() << endl << e.getAditionalInfo() << endl;
		system("pause");
	}
	return 0;
}