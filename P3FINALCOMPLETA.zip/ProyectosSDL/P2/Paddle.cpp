#include "Paddle.h"
#include <iostream>
#include <fstream>
#include "Application.h"
#include "PlayState.h"

//If the paddle is inside the limits, the paddle moves.
void Paddle::update() {
	if (inside())
		pos = pos + speed;
	laserTimer++;
	if (lasers) {//checks if the lasers is active
		if (laserTimer % app->LASER_DELAY == 0)//create lasers every x seconds
			playState->createLasers();
	}
}

//checks is inside the limits
bool Paddle::inside() {
	return (speed.getX() < 0 && getX() > app->WALL_WIDTH + 3 * app->GAP_WIDTH) ||
		(speed.getX() >= 0 && getX() + getW() < app->WIN_WIDTH - app->WALL_WIDTH - 3 * app->GAP_WIDTH);
}

bool Paddle::handleEvent(SDL_Event& event) {
	if (event.type == SDL_KEYDOWN) {
		if (event.key.keysym.sym == SDLK_LEFT) {//left key
			movingRight = false;
			movingLeft = true;

			speed = Vector2D(-(app->PADDLE_SPEED), 0);
		}
		else if (event.key.keysym.sym == SDLK_RIGHT) {//right key
			movingRight = true;
			movingLeft = false;

			speed = Vector2D(app->PADDLE_SPEED, 0);
		}
		else if (event.key.keysym.sym == SDLK_SPACE) {//space key
			playState->setStuckBall(false);
		}

		return true;
	}
	else if (event.type == SDL_KEYUP) {
		if (event.key.keysym.sym == SDLK_LEFT) {//left key up
			if (movingLeft)
				speed = Vector2D(0, 0);
		}
		else if (event.key.keysym.sym == SDLK_RIGHT) {//right key up
			if (movingRight)
				speed = Vector2D(0, 0);
		}

		return true;
	}

	return false;
}

bool Paddle::collides(const SDL_Rect& ballRect, Vector2D& collVector) {
	Vector2D p2 = { double(ballRect.x),  double(ballRect.y) + double(ballRect.h) }; // bottom-left
	Vector2D p3 = { double(ballRect.x) + double(ballRect.w),  double(ballRect.y) + double(ballRect.h) }; // bottom-right

	//Checks that the ball is hitting the top of the paddle.
	if (getY() <= p2.getY() && getY() + getH() > p2.getY() && getX() <= p3.getX() && getX() + getW() >= p2.getX()) {
		double paddleCenter = getX() + getW() / 2;
		double ballCenter = p2.getX() + double(ballRect.w) / 2;
		double distance = paddleCenter - ballCenter;

		//Compare the distance between the center of the ball and the paddle.
		if (distance < 0)
			collVector = { app->REFLECTION,-1 };//Right
		else if (distance > 0)
			collVector = { -(app->REFLECTION),-1 };//Left
		else
			collVector = { 0,-1 };//Center
		return true;
	}
	return false;
}

//modifies the paddle width with the value
void Paddle::modifyWidth(int value) {

	if ((w > app->PADDLE_WIDTH && value < 0) || (w < app->PADDLE_WIDTH && value > 0) || w == app->PADDLE_WIDTH)
	{
		w += value;

		//Centers the paddle after modifying its width
		pos = pos - Vector2D(value / 2, 0);
	}
}

void Paddle::loadFromFile(ifstream& in) {
	MovingObject::loadFromFile(in);//pos
	in >> lasers;//lasers
}

void Paddle::saveToFile(ofstream& out) {
	MovingObject::saveToFile(out);//pos
	out << lasers << endl;//lasers
}

