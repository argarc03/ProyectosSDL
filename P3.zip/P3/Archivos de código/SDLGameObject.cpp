#include "SDLGameObject.h"

void SDLGameObject::render() const {
	SDL_Rect destRect = getRect();
	texture->render(destRect);
}

SDL_Rect SDLGameObject::getRect() const {
	SDL_Rect destRect;
	destRect.x = pos.getX();
	destRect.y = pos.getY();
	destRect.w = w;
	destRect.h = h;

	return destRect;
}