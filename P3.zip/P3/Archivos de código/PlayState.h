#pragma once

#include "GameState.h"

//Object libraries
#include "Vector2D.h"
#include "Wall.h"
#include "BlocksMap.h"
#include "Counter.h"
#include "LifeCounter.h"
#include "LevelCounter.h"
#include "Text.h"
#include "ScreenText.h"

class Paddle;
class Ball;
class LevelReward;
class LifeReward;
class LengthenReward;
class Laser;
class LaserReward;
class ShortenReward;
class StuckReward;
class SuperReward;
class MultipleReward;
class Enemy;

#include <string>

class PlayState :public GameState {
private:
	uint level = 1;
	uint startTime = 0;
	uint lives = 1;

	bool paused = false;
	bool levelWin = false;
	bool gameOver = false;

	//Objects
	Counter* timeCounter = nullptr;
	LifeCounter* lifeCounter = nullptr;
	BlocksMap* blocksMap = nullptr;
	Ball* ball = nullptr;
	Ball* ball2 = nullptr;
	Ball* ball3 = nullptr;
	Paddle* paddle = nullptr;
	uint numEnemies = 0;
	uint numBalls = 1;
	uint numRewards = 0;
	int numLasers = 0;

	Wall* walls[NUM_WALLS];

	list<GameObject*>::iterator firstReward = stage.end();
	list<GameObject*>::iterator firstEnemy = stage.end();
	list<GameObject*>::iterator lastEnemy = stage.end();
	list<GameObject*>::iterator lastLevelObject = stage.end();
public:
	PlayState(Application* app);
	PlayState(Application* app, string code);


	virtual void handleEvent(SDL_Event& event);
	virtual void update();

	bool isPaused() { return paused; };
	void save(string filename);
	void load(string filename);

	void spawnEnemy();

	void init();
	void ballLost(Ball* b);
	void reset();
	void destroyObjects();
	void createObjects();
	void destroyEnemies();
	void destroyRewards();
	void killObject(list<GameObject*>::iterator it);
	void killReward(list<GameObject*>::iterator it);
	void killLasers(list<GameObject*>::iterator it);
	void lifeUp();
	void modifyPaddle(int value);
	void setStickyBall(bool b);
	void setStuckBall(bool b);
	bool getStickyBall();
	void setSuperBall(bool b);
	void multiplyBall();
	void setPaddleLasers(bool value);
	void createLasers();
	void destroyExtraBall(Ball* b);
	bool collidesPaddle(const SDL_Rect& rect);
	void createReward(const SDL_Rect& rect);
	void levelCompleted();
	bool blocksMapCollision(const SDL_Rect& rect, const Vector2D& vel, Vector2D& collVector, bool destroy);
	bool collides(const SDL_Rect& rect, const Vector2D& vel, Vector2D& collVector);
	bool wallCollision(const SDL_Rect& rect, const Vector2D& vel, Vector2D& collVector);
	void toggleLevelWin() {
		levelWin = true;
	};

	virtual void awake() { timeCounter->start(); }; //Starts the timeCounter
};

