#pragma once
#include "checkML.h"
#include "Reward.h"

class LifeReward : public Reward {
public:
	LifeReward() {};
	LifeReward(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		Reward(pos, w, h, speed, 1, app, playState, t) {};

	~LifeReward() {};

	void act();
};