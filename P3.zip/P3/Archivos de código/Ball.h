#pragma once
#include "checkML.h"
#include "MovingObject.h"
#include "Paddle.h"
//#include "Game.h"

typedef unsigned int uint;

class Ball :public MovingObject {
private:
	Paddle* paddle = nullptr;
	bool stuck = true;
	bool sticky = false;
	double paddleOffset = 0;//position offset when the ball is stuck to the paddle 
	bool super = false;
public:
	Ball() {};
	Ball(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Paddle* paddle, Texture* t) :
		MovingObject(pos, w, h, speed, app, playState, t), paddle(paddle) {
		paddleOffset = paddle->getW() / 2 - (w / 2);
	};

	virtual ~Ball() {};

	virtual void update();

	bool getSticky() { return sticky; };
	bool getStuck() { return stuck; };
	void setSticky(bool b) { sticky = b; };
	void setStuck(bool b);
	void setSpeedUp();
	void setPaddleOffset();
	void setPaddleOffset(int value);

	bool getSuper() { return super; }
	void setSuper(bool b) { super = b; }

	Vector2D getSpeed() { return speed; };

	virtual void loadFromFile(ifstream& in);
	virtual void saveToFile(ofstream& out);
};