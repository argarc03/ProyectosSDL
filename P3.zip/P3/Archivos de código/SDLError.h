#pragma once
#include "checkML.h"
#include "ArkanoidError.h"
#include "SDL.h"
#include <string>
#include "SDL_image.h"

class SDLError :public ArkanoidError {
public:
	SDLError(const string& m) : ArkanoidError(m) {};
	~SDLError() {};

	virtual const char* what() const throw() {
		char* result = new char[50];   // array to hold the result.
		strcpy_s(result, 50, ArkanoidError::what()); // copy string one into the result.

		if (SDL_GetError() != "")
			strcat_s(result, 50, SDL_GetError()); // append string two to the result.
		else if (IMG_GetError() != "")
			strcat_s(result, 50, IMG_GetError()); // append string two to the result.

		return result;
	}
};