#pragma once

#include <stack>
//#include "GameState.h"

using namespace std;

class GameState;

class GameStateMachine {
private:
	stack<GameState*> stateStack;
	string gameCode = ""; //The numeric code of the current game
public:
	GameStateMachine() {};
	~GameStateMachine();

	void pushState(GameState* s);
	void popState(int n = 1);
	GameState* currentState();
	void setGameCode(string s) { gameCode = s; };
	string getGameCode() { return gameCode; };
};

