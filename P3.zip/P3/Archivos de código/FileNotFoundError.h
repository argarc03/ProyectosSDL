#pragma once

#include "checkML.h"
#include "ArkanoidError.h"

class FileNotFoundError : public ArkanoidError {
public:
	FileNotFoundError(string foo, string filename) : ArkanoidError("Error loading " + foo + " from " + filename) {};
	~FileNotFoundError() {};
};

