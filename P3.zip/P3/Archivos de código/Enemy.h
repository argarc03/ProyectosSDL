#pragma once
#include "checkML.h"
#include "MovingObject.h"
#include "ArkanoidObject.h"
#include <list>

class Enemy : public MovingObject {
private:
	uint frameRow = 0;
	uint frame = 0;

	int frameRate = 10;//animation speed
	int currentTime = 0;

	int probability = 10;//used for random speed generation
	list<GameObject*>::iterator it;
public:
	Enemy() {};
	Enemy(Vector2D pos, uint w, uint h, Application* app, PlayState* playState, Texture* t) :
		MovingObject(pos, w, h, Vector2D(0, 0), app, playState, t) {};
	~Enemy() {};

	virtual void render() const;
	void update();
	bool collides(const SDL_Rect& ballRect, Vector2D& collVector);
	void setItList(list<GameObject*>::iterator itFR);
	void destroy();
};