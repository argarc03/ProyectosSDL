#include "PauseState.h"
#include "PlayState.h"

PlayState* PauseState::playState = nullptr;

PauseState::PauseState(Application* app, PlayState* playState) : GameState(app)
{
	PauseState::playState = playState;
	stage.push_back(new Button(100, 50, Vector2D(app->WIN_WIDTH / 2 - 50, app->WIN_HEIGHT / 2 - 100), app, resume, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(ResumeText)])); // Resume Button
	stage.push_back(new Button(100, 50, Vector2D(app->WIN_WIDTH / 2 - 50, app->WIN_HEIGHT / 2), app, PauseState::save, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(SaveText)]));// Save Button
	stage.push_back(new Button(300, 50, Vector2D(app->WIN_WIDTH / 2 - 150, app->WIN_HEIGHT / 2 + 100), app, PauseState::mainMenu, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(MainMenuText)]));// Main Menu Button
}

void PauseState::handleEvent(SDL_Event& event) {

	GameState::handleEvent(event);

	if (event.type == SDL_KEYDOWN) {
		if (event.key.keysym.sym == SDLK_ESCAPE)
			resume(app);
	}
}

void PauseState::resume(Application* app) {
	auto tempState = playState;
	app->getStateMachine()->popState();
	tempState->awake();
}

void PauseState::save(Application* app) {
	playState->save("");
}

void PauseState::mainMenu(Application* app) {
	app->getStateMachine()->popState(2);
}