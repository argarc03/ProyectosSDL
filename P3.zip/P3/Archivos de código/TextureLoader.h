#pragma once
#include <map>
#include "Texture.h"
#include <fstream>
#include "Font.h"

using namespace std;

class TextureLoader {
private:
	const string PATH = "..\\images\\";
	const string FONT_PATH = "..\\fonts\\";

	map<string, Texture*> textures; //texture dictionary
	static TextureLoader* instance; //texture loader instance 
	SDL_Renderer* renderer;
	TextureLoader() {};
	~TextureLoader() {
		for (auto it : textures) {
			delete it.second;
		}

		textures.clear();

		instance = nullptr;
	};
public:
	//returns the TextureLoader instance
	static TextureLoader* getInstance() {
		if (instance == nullptr) {
			instance = new TextureLoader();

		}
		return instance;
	}

	//gets the renderer that is being used
	static void initializer(SDL_Renderer* r) {
		instance->renderer = r;
	}

	//deletes the instance
	static void uninitializer() {
		delete instance;
	}

	//adds a new texture to the dictionary
	void add(string name, string path, int rows, int cols) {
		textures[name] = new Texture(renderer, path, rows, cols);
	}

	Texture* get(string textureName) {
		return textures[textureName];
	}

	//Loads from file the texture data
	void load(string path) {
		ifstream in(path);

		while (in.is_open()) {
			string name, textPath;
			int rows, cols;
			in >> name >> textPath >> rows >> cols;
			if (name == "") break;
			add(name, PATH + textPath, rows, cols);
		}

		in.close();
	}

	SDL_Renderer* getRenderer() { return renderer; }
};