#pragma once
#include "checkML.h"
#include "Reward.h"
class LaserReward :
	public Reward
{
public:
	LaserReward() {};
	LaserReward(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		Reward(pos, w, h, speed, 7, app, playState, t) {};

	~LaserReward() {};

	void act();
};
