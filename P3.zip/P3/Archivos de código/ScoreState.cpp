#include "ScoreState.h"
#include <fstream>
#include "Counter.h"
#include "Text.h"
#include <algorithm>
#include "ScreenState.h"
#include <Windows.h>

ScoreState::ScoreState(Application* app, int score) : GameState(app)
{
	//Your time
	stage.push_back(new Text(10 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, Vector2D(app->WIN_WIDTH / 2 - 10 * app->WALL_WIDTH, 2 * app->WALL_WIDTH), TextureLoader::getInstance()->get("YourTimeText")));
	//Final Score
	stage.push_back(new Counter(Vector2D(app->WIN_WIDTH / 2 + 4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH), 4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, score, app->NUM_DIGITS_SCORE, TextureLoader::getInstance()->get("DigitsText")));
	//Best times
	stage.push_back(new Text(10 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, Vector2D(app->WIN_WIDTH / 2 - 5 * app->WALL_WIDTH, 5 * app->WALL_WIDTH), TextureLoader::getInstance()->get("BestTimesText")));

	nicks = new Texture*[HIGH_SCORE_TOP_SIZE];
	dates = new Texture*[HIGH_SCORE_TOP_SIZE];

	loadScore();
	saveScore(score);

	int i = 0;
	for (auto it = scores.begin(); it != scores.end(); ++it) {
		stage.push_back(new Counter(Vector2D(app->WIN_WIDTH / 2 - 2 * app->WALL_WIDTH, 8 * app->WALL_WIDTH + i * 2 * app->WALL_WIDTH), 4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH, it->first.first, app->NUM_DIGITS_SCORE, TextureLoader::getInstance()->get("DigitsText")));
		nicks[i] = new Texture(app->getRenderer(), it->second, (*app->getFont()), { 255,255,255 });
		dates[i] = new Texture(app->getRenderer(), it->first.second, (*app->getFont()), { 255,255,255 });
		stage.push_back(new Text(4 * app->WALL_WIDTH, 2 * app->WALL_WIDTH + 10, Vector2D(app->WIN_WIDTH / 2 - 2 * app->WALL_WIDTH - 100, 8 * app->WALL_WIDTH + i * 2 * app->WALL_WIDTH - 5), nicks[i]));
		stage.push_back(new Text(6 * app->WALL_WIDTH, 2 * app->WALL_WIDTH + 20, Vector2D(app->WIN_WIDTH / 2 - 2 * app->WALL_WIDTH + 100, 8 * app->WALL_WIDTH + i * 2 * app->WALL_WIDTH - 10), dates[i]));
		i++;
	}

	stage.push_back(new Button(100, 50, Vector2D(app->WIN_WIDTH - 140, app->WIN_HEIGHT - 90), app, ScoreState::endState, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(ContinueText)]));
}

void ScoreState::endState(Application* app) {
	app->getStateMachine()->popState();
}

int ScoreState::getPlayerScorePosition(string nick) {
	int cont = 0;
	bool found = false;

	auto it = scores.begin();
	while (it != scores.end() && !found) {
		auto next = it;
		++next;

		if (it->second == nick)
			found = true;
		else
			cont++;
		it = next;
	}

	return cont;
}

//Saves the top-10 scores to "scores.txt"
void ScoreState::saveScore(int time) {
	int score = time; //gets the time
	auto it = scores.end();
	--it;
	int lastScore = it->first.first;
	if (score < lastScore) {//if time is inside the top-10
		string nick = inputNickSave();

		SYSTEMTIME time;
		GetLocalTime(&time);

		if (scores.find(make_pair(score, to_string(time.wDay) + "/" + to_string(time.wMonth) + "/" + to_string(time.wYear))) == scores.end()) {
			scores.erase(it);
			scores.insert({ make_pair(score,to_string(time.wDay) + "/" + to_string(time.wMonth) + "/" + to_string(time.wYear)), nick }); //cambiar fecha y nickname 
		}

		ofstream out;
		out.open(app->SAVES_PATH + "score.txt");

		if (!out.is_open())
			throw FileNotFoundError("score", "score.txt");
		else {
			auto scoreIt = scores.begin();
			//writes all scores in score.txt with the actual player's one already added to scores' map
			for (int i = 0; i < HIGH_SCORE_TOP_SIZE; i++) {
				out << scoreIt->second << " " << scoreIt->first.second << " " << scoreIt->first.first << endl; //writes: nick date score
				++scoreIt;
			}
		}

		out.close();
	}
}

//asks the player for a 3 letters name
string ScoreState::inputNickSave() {
	string s = "";

	do {
		cout << "Introduce your nickname (3 letters): ";
		cin >> s;

		if (app->is_number(s))//if the input is not a group of letters letter, asks again
			cout << "This is not a valid code." << endl;
		else if (s.size() != 3)//if the nick is not a 3 letters nick, asks again
			cout << "Invalid code length." << endl;
	} while (app->is_number(s) || s.size() != 3);

	system("cls");//console clear
	return s;
}

//Loads the top-10 scores from "scores.txt".
//If it doesnt exist, it creates it and fill it with 999...9
void ScoreState::loadScore() {
	ifstream in;
	string filename = app->SAVES_PATH + "score.txt";
	in.open(filename);

	if (!in.is_open()) {
		//throw FileNotFoundError("score", filename);
		ofstream out;
		out.open(filename);

		for (int i = 0; i < HIGH_SCORE_TOP_SIZE; i++) {
			scores.insert({ make_pair(9999, to_string(30 - i) + "/2/1999"), "AAA" });
			out << "AAA " << "28/2/1999 " << 9999 << endl;
		}

		out.close();
	}
	else {
		for (int i = 0; i < HIGH_SCORE_TOP_SIZE; i++) {
			string nick, date;
			int score;

			in >> nick;
			in >> date;
			in >> score;

			scores.insert({ make_pair(score,date),nick });
		}
	}

	in.close();
}