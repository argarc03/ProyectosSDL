#include "LifeReward.h"
#include "Application.h"
#include "PlayState.h"

void LifeReward::act() {
	playState->lifeUp();
}
