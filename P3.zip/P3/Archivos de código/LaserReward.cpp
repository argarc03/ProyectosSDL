#include "LaserReward.h"
#include "Application.h"
#include "PlayState.h"

void LaserReward::act() {
	playState->setPaddleLasers(true);
}