#pragma once

#include "GameState.h"
#include "ArkanoidObject.h"
#include "ScreenText.h"

class PlayState;

class ScreenState :public GameState {
protected:
	uint32_t startTime;
	uint32_t timeInScreen;
	static PlayState* playState;
public:
	ScreenState(Application* app, uint32_t time, string textureName, PlayState* playState) : GameState(app) {
		ScreenState::playState = playState;
		startTime = SDL_GetTicks();
		timeInScreen = time;
		stage.push_back(new ScreenText(app->WIN_WIDTH * 3 / 4, app->WIN_HEIGHT / 4, Vector2D(app->WIN_WIDTH / 8, app->WIN_HEIGHT / 8 * 3), TextureLoader::getInstance()->get(textureName)));
	}

	virtual void update();
	virtual ~ScreenState() {};
};