#pragma once

#include "Application.h"
#include "GameObject.h"
#include <list>

using namespace std;

class GameState {
protected:
	list<GameObject*> stage; //state objects
	Application* app;
public:
	GameState(Application* app) :app(app) {};
	virtual ~GameState() {
		for (GameObject* o : stage)
			delete o;

		stage.clear();
	};

	virtual void update() {
		for (auto it = stage.begin(); it != stage.end();) {
			auto next = it;
			++next;
			(*it)->update();
			it = next;
		}
	}

	virtual void handleEvent(SDL_Event& e) {
		bool handled = false;

		auto it = stage.begin();
		while (!handled && it != stage.end()) {
			if ((*it++)->handleEvent(e))
				handled = true;
		}
	}

	virtual void render() const {
		for (GameObject* o : stage)
			o->render();
	}

	virtual void init() {  };
	virtual void awake() {  };
};

