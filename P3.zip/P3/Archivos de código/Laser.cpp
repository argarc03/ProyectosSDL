#include "Laser.h"
#include "Application.h"
#include <iostream>
#include "PlayState.h"

void Laser::update() {
	MovingObject::update();//Move

	//Collision
	Vector2D aux = { 0,0 };
	if (playState->blocksMapCollision(getRect(), speed, aux, true) || getY() < 3 * app->WALL_WIDTH) { //Asks the game if there is a collision with either the blocksMap or the topWall
		playState->killLasers(it);//gets destroyed
	}
}

void Laser::setItList(list<GameObject*>::iterator _it) {
	it = _it;
}