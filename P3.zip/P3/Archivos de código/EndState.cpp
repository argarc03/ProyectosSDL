#include "EndState.h"

EndState::EndState(Application* app) : GameState(app) {
	stage.push_back(new Button(300, 50, Vector2D(app->WIN_WIDTH / 2 - 150, app->WIN_HEIGHT / 2 - 100), app, mainMenu, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(MainMenuText)]));// Main Menu
	stage.push_back(new Button(100, 50, Vector2D(app->WIN_WIDTH / 2 - 50, app->WIN_HEIGHT / 2 + 100), app, quit, TextureLoader::getInstance()->get("ButtonText"), app->textTextures[TextName(QuitText)]));
}

void EndState::mainMenu(Application* app) {
	app->getStateMachine()->popState(2);
}

void EndState::quit(Application* app) {
	app->setExit(true);
}
