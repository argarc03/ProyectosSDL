#include "ScreenState.h"
#include "PlayState.h"

PlayState* ScreenState::playState = nullptr;

void ScreenState::update() {
	if (SDL_GetTicks() - startTime > timeInScreen) {
		auto tempState = playState;
		app->getStateMachine()->popState(); //returns to playState
		tempState->awake(); //starts playStates's timeCounter
	}
}