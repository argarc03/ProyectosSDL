#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "checkML.h"
#include <list>

#include "Button.h"

#include "Vector2D.h"
#include "Wall.h"
#include "BlocksMap.h"
#include "Paddle.h"
#include "Ball.h"
#include "Counter.h"
#include "LifeCounter.h"
#include "LevelCounter.h"
#include "Text.h"
#include "ScreenText.h"
#include "LevelReward.h"
#include "LifeReward.h"
#include "LengthenReward.h"
#include "Laser.h"
#include "LaserReward.h"
#include "ShortenReward.h"
#include "StuckReward.h"
#include "SuperReward.h"
#include "MultipleReward.h"
#include "Enemy.h"
#include "TextureLoader.h"

#include "GameState.h"
#include "GameStateMachine.h"

/*
	BUGS:
	- La bola atraviesa el paddle en algunos �ngulos.
	- A veces no pierdes cuando la bola cae.
	- Algunas bolas clones rebotan contra enemies o bloques y desaparecen.
*/

typedef unsigned int uint;

//constants used by static arrays
const uint NUM_WALLS = 3;
const uint HIGH_SCORE_TOP_SIZE = 10;
const uint TEXT_TEXTURES_SIZE = 7;

const string texts[] = { "NEW GAME","CONTINUE GAME","QUIT","RESUME","SAVE","BACK TO MAIN MENU","CONTINUE" };


enum WallName { LeftWall, RightWall, TopWall };
enum RewardType { LevelRew, LifeRew, LengthenRew, ShortenRew, StuckRew, SuperRew, MultipleRew, LaserRew };

enum TextName { NewGameText, ContinueGameText, QuitText, ResumeText, SaveText, MainMenuText, ContinueText };

struct WallAtributes {
	uint w;
	uint h;
	Vector2D pos;
	Vector2D coll;
	string textureName;
};

class Application {
private:
	SDL_Window* window = nullptr;
	SDL_Renderer* renderer = nullptr;

	bool exit = false;

	GameStateMachine stateMachine; //Game states machine
public:
	//Global Parameters
	uint NUM_TEMPORAL_OBJECTS = 5;

	uint WIN_WIDTH = 800;
	uint WIN_HEIGHT = 600;
	uint FRAME_RATE = 20;

	uint BALL_SIZE = 20;
	double BALL_SPEED = 10;

	uint PADDLE_WIDTH = 80;
	uint PADDLE_HEIGHT = 20;
	int PADDLE_SPEED = 10;

	uint WALL_WIDTH = 20;
	uint GAP_WIDTH = 4;

	string IMAGES_PATH = "..\\images\\";
	string LEVELS_PATH = "..\\levels\\";
	string SAVES_PATH = "..\\saves\\";

	uint TOTAL_LEVELS = 3;
	uint TOTAL_LIVES = 3;

	uint NUM_DIGITS_SCORE = 4;
	uint NUM_DIGITS_LEVEL = 2;

	uint WALL_COLLIDES_OFFSET = 6;
	double REFLECTION = 0.25;

	int REWARD_PROBABILITY = 5;
	uint REWARD_WIDTH = 40;
	uint REWARD_HEIGHT = 20;
	int REWARD_SPEED = 3;
	uint NUM_REWARDS = 8;
	int PADDLE_MODIFY_VALUE = 50; //Paddle width modifier's constant value

	uint LASER_WIDTH = 7;
	uint LASER_HEIGHT = 23;
	double LASER_SPEED = 10;
	uint LASER_DELAY = 40;

	int ENEMY_PROBABILITY = 200;
	double ENEMY_SPEED = 3;
	int ENEMY_WIDTH = 30;
	int ENEMY_HEIGHT = 40;
	int MAX_ENEMIES = 5;

	int BLOCK_NUM_COLORS = 6;

	WallAtributes wallAtrib[NUM_WALLS] = {
	{WALL_WIDTH,WIN_HEIGHT,Vector2D(GAP_WIDTH,2 * WALL_WIDTH),Vector2D(1,0),"SideText"},
	{WALL_WIDTH, WIN_HEIGHT, Vector2D(WIN_WIDTH - WALL_WIDTH - GAP_WIDTH, 2 * WALL_WIDTH),Vector2D(-1,0), "SideText"},
	{WIN_WIDTH, WALL_WIDTH, Vector2D(0, 2 * WALL_WIDTH),Vector2D(0,1), "TopSideText" }
	};

	TextureLoader* textures;

	Font* font;

	Texture** textTextures;

	//Methods
	Application();
	~Application();

	void run();
	void render();

	void handleEvents();

	void saveConfig();
	void loadFromConfig();

	bool is_number(const string& s);

	string inputTextLoad();
	string inputTextSave();

	void setExit(bool b) { exit = b; };

	GameStateMachine* getStateMachine() {
		return &stateMachine;
	}

	SDL_Renderer* getRenderer() { return renderer; }
	Font* getFont() { return font; }
};