#ifndef GameH
#define GameH

#include "checkML.h"
#include "Application.h"
#include "Texture.h" 
#include <iostream>
#include <fstream>
#include <algorithm>
#include <windows.h>
#include <time.h>
#include <math.h>
#include "SDLError.h"
#include "FileNotFoundError.h"
#include "MainMenuState.h"

using namespace std;

Application::Application() {
	srand(time(nullptr));//random seed

	// We first initialize SDL
	SDL_Init(SDL_INIT_EVERYTHING);
	window = SDL_CreateWindow("Arkanoid", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
		WIN_WIDTH, WIN_HEIGHT, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if (window == nullptr || renderer == nullptr) throw SDLError("Error loading the SDL window or renderer");
	string filename = IMAGES_PATH + "icon.png";
	SDL_Surface* iconSurface = IMG_Load(filename.c_str());
	if (iconSurface == nullptr) throw FileNotFoundError("iconSurface", filename);
	SDL_SetWindowIcon(window, iconSurface);

	TTF_Init();//initialize TTF library

	try
	{
		loadFromConfig(); //loads the game config
	}
	catch (FileNotFoundError& e)
	{
		cout << e.what() << endl << "Default configuration will be loaded." << endl;
	}


	textures = TextureLoader::getInstance();
	TextureLoader::initializer(renderer); //sets the rendererer of TextureLoader
	textures->load("..\\images\\textures.txt");


	font = new Font("..\\fonts\\Oswald-Regular.ttf", 12);

	textTextures = new Texture*[TEXT_TEXTURES_SIZE];

	for (int i = 0; i < TEXT_TEXTURES_SIZE; i++)
		textTextures[i] = new Texture(renderer, texts[i], *font, { 255,255,255 });


	stateMachine.pushState(new MainMenuState(this));
}
Application::~Application() {
	TextureLoader::uninitializer(); //destroy the textures

	for (int i = 0; i < TEXT_TEXTURES_SIZE; i++)
		delete textTextures[i];
	delete[] textTextures;

	delete font;

	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);

	TTF_Quit();

	SDL_Quit();
}

//checks if the string is a number
bool Application::is_number(const string& s)
{
	string::const_iterator it = s.begin();
	while (it != s.end() && isdigit(*it)) ++it;
	return !s.empty() && it == s.end();
}

//asks the user a numeric filename in console to load game
string Application::inputTextLoad() {
	string s = "";

	ifstream in;
	in.open(s + ".txt");
	do {
		cout << "Introduce a numeric code: ";
		cin >> s;
		in.open(s + ".txt");

		if (!is_number(s))//if the input is not a number, asks again
			cout << "This is not a numeric code." << endl;
		else if (!in.is_open())//if there is not a file with the given filename, asks again
			cout << "There is no file with such name." << endl;
	} while (!in.is_open() || !is_number(s));

	in.close();

	system("cls");//console clear
	return s + ".txt";
}

//asks the user a numeric filename in console to save game
string Application::inputTextSave() {
	string s = "";

	cout << "Introduce a numeric code: ";
	cin >> s;

	while (!is_number(s)) {//if the input is not a number, asks again
		cout << "This is not a numeric code." << endl;
		cout << "Introduce a numeric code: ";
		cin >> s;
	}

	system("cls");//console clear
	return s + ".txt";
}

void Application::run() {
	uint32_t startTime, frameTime;
	startTime = SDL_GetTicks();
	while (!exit) {//GAME LOOP
		handleEvents();
		frameTime = SDL_GetTicks() - startTime; // Tiempo desde �ltima actualizaci�n
		if (frameTime >= FRAME_RATE) {
			stateMachine.currentState()->update();

			startTime = SDL_GetTicks();
		}
		if (!exit)
			render();
	}
}

void Application::render() {
	SDL_RenderClear(renderer);

	stateMachine.currentState()->render();

	SDL_RenderPresent(renderer);
}

void Application::handleEvents() {
	SDL_Event event;
	while (SDL_PollEvent(&event) && !exit) {
		if (event.type == SDL_QUIT) {
			exit = true;
		}
		else
			stateMachine.currentState()->handleEvent(event);
	}
}

//Saves all the constant parameters of the game to "config.cfg"
void Application::saveConfig() {
	ofstream out;
	out.open("config.cfg");

	out << "NUM_TEMPORAL_OBJECTS " << NUM_TEMPORAL_OBJECTS << endl;
	out << "WIN_WIDTH " << WIN_WIDTH << endl;
	out << "WIN_HEIGHT " << WIN_HEIGHT << endl;
	out << "FRAME_RATE " << FRAME_RATE << endl;

	//ball
	out << "BALL_SIZE " << BALL_SIZE << endl;
	out << "BALL_SPEED " << BALL_SPEED << endl;

	//paddle
	out << "PADDLE_WIDTH " << PADDLE_WIDTH << endl;
	out << "PADDLE_HEIGHT " << PADDLE_HEIGHT << endl;
	out << "PADDLE_SPEED " << PADDLE_SPEED << endl;

	//wall
	out << "WALL_WIDTH " << WALL_WIDTH << endl;
	out << "GAP_WIDTH " << GAP_WIDTH << endl;

	//file paths
	out << "IMAGES_PATH " << IMAGES_PATH << endl;
	out << "LEVELS_PATH " << LEVELS_PATH << endl;

	//levels/lives
	out << "TOTAL_LEVELS " << TOTAL_LEVELS << endl;
	out << "TOTAL_LIVES " << TOTAL_LIVES << endl;

	//text
	out << "NUM_DIGITS_SCORE " << NUM_DIGITS_SCORE << endl;
	out << "NUM_DIGITS_LEVEL " << NUM_DIGITS_LEVEL << endl;

	//collision
	out << "WALL_COLLIDES_OFFSET " << WALL_COLLIDES_OFFSET << endl;
	out << "REFLECTION " << REFLECTION << endl;

	//reward
	out << "REWARD_PROBABILITY " << REWARD_PROBABILITY << endl;
	out << "REWARD_WIDTH " << REWARD_WIDTH << endl;
	out << "REWARD_HEIGHT " << REWARD_HEIGHT << endl;
	out << "REWARD_SPEED " << REWARD_SPEED << endl;
	out << "NUM_REWARDS " << NUM_REWARDS << endl;
	out << "PADDLE_MODIFY_VALUE " << PADDLE_MODIFY_VALUE << endl;

	//laser
	out << "LASER_WIDTH " << LASER_WIDTH << endl;
	out << "LASER_HEIGHT " << LASER_HEIGHT << endl;
	out << "LASER_SPEED " << LASER_SPEED << endl;
	out << "LASER_DELAY " << LASER_DELAY << endl;

	//enemy
	out << "ENEMY_PROBABILITY " << ENEMY_PROBABILITY << endl;
	out << "ENEMY_SPEED " << ENEMY_SPEED << endl;
	out << "ENEMY_WIDTH " << ENEMY_WIDTH << endl;
	out << "ENEMY_HEIGHT " << ENEMY_HEIGHT << endl;
	out << "MAX_ENEMIES " << MAX_ENEMIES << endl;

	out.close();
}

//Loads the game configuration from config.cfg
void Application::loadFromConfig() {
	ifstream in;
	in.open("config.cfg");
	if (!in.is_open())
		throw FileNotFoundError("configuration", "config.cfg");

	string s = "";

	in >> s >> NUM_TEMPORAL_OBJECTS;
	in >> s >> WIN_WIDTH;
	in >> s >> WIN_HEIGHT;
	in >> s >> FRAME_RATE;

	//ball
	in >> s >> BALL_SIZE;
	in >> s >> BALL_SPEED;

	//paddle
	in >> s >> PADDLE_WIDTH;
	in >> s >> PADDLE_HEIGHT;
	in >> s >> PADDLE_SPEED;

	//wall
	in >> s >> WALL_WIDTH;
	in >> s >> GAP_WIDTH;

	//file paths
	in >> s >> IMAGES_PATH;
	in >> s >> LEVELS_PATH;

	//levels/lives
	in >> s >> TOTAL_LEVELS;
	in >> s >> TOTAL_LIVES;

	//text
	in >> s >> NUM_DIGITS_SCORE;
	in >> s >> NUM_DIGITS_LEVEL;

	//collision
	in >> s >> WALL_COLLIDES_OFFSET;
	in >> s >> REFLECTION;

	//reward
	in >> s >> REWARD_PROBABILITY;
	in >> s >> REWARD_WIDTH;
	in >> s >> REWARD_HEIGHT;
	in >> s >> REWARD_SPEED;
	in >> s >> NUM_REWARDS;
	in >> s >> PADDLE_MODIFY_VALUE;

	//laser
	in >> s >> LASER_WIDTH;
	in >> s >> LASER_HEIGHT;
	in >> s >> LASER_SPEED;
	in >> s >> LASER_DELAY;

	//enemy
	in >> s >> ENEMY_PROBABILITY;
	in >> s >> ENEMY_SPEED;
	in >> s >> ENEMY_WIDTH;
	in >> s >> ENEMY_HEIGHT;
	in >> s >> MAX_ENEMIES;

	in.close();
}
#endif