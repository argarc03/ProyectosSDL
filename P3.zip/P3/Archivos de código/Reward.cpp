#include "Reward.h"
#include "Application.h"
#include <fstream>
#include "PlayState.h"

using namespace std;

void Reward::render() const {
	SDL_Rect destRect = getRect();

	texture->renderFrame(destRect, type, frame);
}

void Reward::setItList(list<GameObject*>::iterator itFR) {
	it = itFR;
}

void Reward::update() {
	MovingObject::update();//Move
	frame = (frame + 1) % texture->getNumCols();//Animation

	//Collision
	if (playState->collidesPaddle(getRect())) { //Asks the game if there is a collision
		act();
		playState->killReward(it);
	}
	else if (pos.getY() >= app->WIN_HEIGHT + 2 * app->BALL_SIZE)//If the reward is under the paddle, it is destroyed
		playState->killReward(it);
}

void Reward::loadFromFile(ifstream& in) {
	ArkanoidObject::loadFromFile(in);
}

void Reward::saveToFile(ofstream& out) {
	out << type << endl;
	ArkanoidObject::saveToFile(out);
}