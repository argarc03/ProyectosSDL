#pragma once
#include "checkML.h"
#include "Reward.h"

class LevelReward : public Reward {
public:
	LevelReward() {};
	LevelReward(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		Reward(pos, w, h, speed, 0, app, playState, t) {};

	~LevelReward() {};

	void act();
};