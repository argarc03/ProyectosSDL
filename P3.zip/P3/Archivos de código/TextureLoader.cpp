#include "TextureLoader.h"

TextureLoader* TextureLoader::instance=nullptr;