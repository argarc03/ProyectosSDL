#include "ShortenReward.h"
#include "Application.h"
#include "PlayState.h"

void ShortenReward::act() {
	playState->modifyPaddle(-(app->PADDLE_MODIFY_VALUE));
}