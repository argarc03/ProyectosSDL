#pragma once
#include "checkML.h"
#include "SDLGameObject.h"

typedef unsigned int uint;

class ScreenText : public SDLGameObject {
public:
	ScreenText() {}
	ScreenText(uint w, uint h, Vector2D pos, Texture* t) :
		SDLGameObject(w, h, pos, t) {}
	~ScreenText() {}
};