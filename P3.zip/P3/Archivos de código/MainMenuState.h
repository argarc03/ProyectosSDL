#pragma once

#include "GameState.h"
#include "PlayState.h"

class MainMenuState :public GameState {
public:
	MainMenuState(Application* app);

	static void newGame(Application* app);
	static void continueGame(Application* app);
	static void quit(Application* app);

	virtual void init();
};