#include "LevelReward.h"
#include "Application.h"
#include "PlayState.h"

void LevelReward::act() {
	playState->toggleLevelWin();//level completed
}
