#pragma once
#include "checkML.h"
#include "Reward.h"
class StuckReward :
	public Reward
{
public:
	StuckReward() {};
	StuckReward(Vector2D pos, uint w, uint h, Vector2D speed, Application* app, PlayState* playState, Texture* t) :
		Reward(pos, w, h, speed, 4, app, playState, t) {};

	~StuckReward() {};

	void act();
};