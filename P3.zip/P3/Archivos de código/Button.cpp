#include "Button.h"
#include "Application.h"

void Button::render() const {
	backgroundText->renderFrame(getRect(), 0, frame);
	SDLGameObject::render();
}

bool Button::handleEvent(SDL_Event& event) {
	if (event.type == SDL_MOUSEMOTION) {//if mouse is moving
		SDL_Point p = { event.motion.x, event.motion.y };

		if (SDL_PointInRect(&p, &getRect())) {//if mouse position is inside the button rect
			in = true;
			frame = 1;//change sprite to over
		}
		else {
			in = false;
			frame = 0;//change sprite to normal
		}
	}
	else if (event.type == SDL_MOUSEBUTTONDOWN) {
		if (in && event.button.button == SDL_BUTTON_LEFT) {//if mouse left click
			frame = 2;//change sprite to pressed
			cb(app);									

			return true;
		}
	}

	return false;
}