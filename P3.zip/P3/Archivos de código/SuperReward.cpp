#include "SuperReward.h"
#include "Application.h"
#include "PlayState.h"

void SuperReward::act() {
	playState->setSuperBall(true);
}