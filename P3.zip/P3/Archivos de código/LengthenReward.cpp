#include "LengthenReward.h"
#include "Application.h"
#include "PlayState.h"

void LengthenReward::act() {
	playState->modifyPaddle(app->PADDLE_MODIFY_VALUE);
}