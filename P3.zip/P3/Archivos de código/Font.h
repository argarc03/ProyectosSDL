#pragma once

#include <string>
#include "checkML.h"
#include "SDL.h"
#include "SDL_ttf.h"
#include "checkML.h"

using namespace std;

class Font {
private:
	TTF_Font* font = nullptr;
public:
	Font() {};
	Font(string filename, int size) {
		load(filename, size);
	}
	~Font() { clean(); }
	bool load(string filename, int size) {
		font = TTF_OpenFont(filename.c_str(), size);

		return true;
	}
	void clean() {
		if (font != nullptr) TTF_CloseFont(font);
		font = nullptr;
	}
	SDL_Surface* generateSurface(string text, SDL_Color color) const {
		return TTF_RenderText_Solid(font, text.c_str(), color);
	}
};