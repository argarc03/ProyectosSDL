#pragma once

#include "checkML.h"
#include "ArkanoidObject.h"

class Application;

using CallBackOnClick = void(Application* app);

class Button : public SDLGameObject {
private:
	CallBackOnClick* cb = nullptr; //button's callback
	Application* app = nullptr;
	int frame = 0;
	bool in = false;
	Texture* backgroundText = nullptr;
public:
	Button() {};
	Button(uint w, uint h, Vector2D pos, Application* app, CallBackOnClick* cb, Texture* backgroundText, Texture* t) : SDLGameObject(w, h, pos, t), app(app), cb(cb), backgroundText(backgroundText) {};
	~Button() {};

	virtual bool handleEvent(SDL_Event& event);
	void render() const;
};